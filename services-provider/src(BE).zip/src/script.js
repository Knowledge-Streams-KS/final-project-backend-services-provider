// import bcrypt from "bcryptjs";
// import User from "./models/userModel"; // adjust the path according to your project structure

// const createAdmin = async () => {
//   const adminData = {
//     firstName: "Waqas",
//     lastName: "Raza",
//     email: "support@admin.com",
//     password: bcrypt.hashSync("Um@09291916", 10), // securely hash the password
//     role: "admin",
//   };

//   try {
//     await User.create(adminData);
//     console.log("Admin user created successfully");
//   } catch (error) {
//     console.error("Error creating admin user:", error);
//   }
// };

// createAdmin();
